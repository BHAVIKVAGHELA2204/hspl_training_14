odoo.define('website.post_link', function (require) {
'use strict';

    $(function() {
      $('#dp').datepicker();
    });

});